
import React, { useState } from 'react';
import { VideoItem } from '../types';
import { CARD_WIDTH, CARD_HEIGHT } from '../config';

interface VideoCardProps {
  video: VideoItem;
  style?: React.CSSProperties; // For sphere layout transforms
  isSphereItem?: boolean;
}

const InstagramIcon: React.FC<{ className?: string }> = ({ className = "w-4 h-4" }) => (
  <svg
    className={className}
    fill="currentColor"
    viewBox="0 0 24 24"
    aria-hidden="true"
  >
    <path
      fillRule="evenodd"
      d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 16c-3.314 0-6-2.686-6-6s2.686-6 6-6 6 2.686 6 6-2.686 6-6 6zm0-10c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm5.5-1.5c-.828 0-1.5.672-1.5 1.5s.672 1.5 1.5 1.5 1.5-.672 1.5-1.5-.672-1.5-1.5-1.5zm-7 3.5c0-1.381 1.119-2.5 2.5-2.5s2.5 1.119 2.5 2.5-1.119 2.5-2.5 2.5-2.5-1.119-2.5-2.5z"
      clipRule="evenodd"
    />
  </svg>
);


const VideoCard: React.FC<VideoCardProps> = ({ video, style, isSphereItem = false }) => {
  const [imageHasError, setImageHasError] = useState(false);

  const cardBaseClasses = "bg-gray-800 rounded-lg shadow-lg overflow-hidden transition-all duration-300 ease-in-out flex flex-col";
  const cardHoverClasses = !isSphereItem ? "hover:shadow-xl hover:ring-2 hover:ring-indigo-500" : "";
  
  const cardSizeStyle = {
    width: `${CARD_WIDTH}px`,
    height: `${CARD_HEIGHT}px`,
  };

  const sphereItemStyle = isSphereItem ? {
    ...style,
    ...cardSizeStyle,
    marginLeft: `-${CARD_WIDTH / 2}px`,
    marginTop: `-${CARD_HEIGHT / 2}px`,
  } : {};

  const gridItemStyle = !isSphereItem ? cardSizeStyle : {};

  const handleImageError = () => {
    console.error(`Failed to load thumbnail for ${video.title}: ${video.thumbnailUrl}`);
    setImageHasError(true);
  };
  
  const handleInstagramLinkClick = (event: React.MouseEvent) => {
    event.stopPropagation(); // Prevent the main card's YouTube link from triggering
  };

  return (
    <a
      href={video.youtubeLink}
      target="_blank"
      rel="noopener noreferrer"
      title={`${video.title} - ${video.channel}\nClick to watch on YouTube`}
      className={`${cardBaseClasses} ${cardHoverClasses} ${isSphereItem ? 'video-card-sphere' : ''}`}
      style={isSphereItem ? sphereItemStyle : { ...style, ...gridItemStyle }}
      aria-label={`Watch ${video.title} on YouTube`}
    >
      <div className="w-full h-[70px] overflow-hidden bg-gray-700 flex items-center justify-center"> {/* Ensure container always has a background and centers content */}
        {imageHasError ? (
          <span className="text-gray-400 text-xs p-1">No preview</span>
        ) : (
          <img
            src={video.thumbnailUrl}
            alt={`Preview for ${video.title}`}
            className="w-full h-full object-cover"
            loading="lazy"
            onError={handleImageError}
          />
        )}
      </div>
      <div className="p-2 flex-grow flex flex-col justify-center"> {/* Text content below image */}
        <h3 className="text-sm font-semibold text-indigo-300 mb-0.5 truncate w-full" title={video.title}>
          {video.title}
        </h3>
        <div className="flex justify-between items-center w-full">
          <p className="text-xs text-gray-400 truncate" title={video.channel}>
            {video.channel}
          </p>
          <a
            href={video.instagramLink}
            target="_blank"
            rel="noopener noreferrer"
            onClick={handleInstagramLinkClick}
            title={`Visit ${video.channel} on Instagram`}
            aria-label={`Visit ${video.channel} on Instagram`}
            className="text-pink-400 hover:text-pink-300 transition-colors ml-1 p-1 rounded-md" // Added p-1 and rounded-md
          >
            <InstagramIcon className="w-5 h-5" /> {/* Increased size */}
          </a>
        </div>
      </div>
    </a>
  );
};

export default VideoCard;