
import React from 'react';
import { LayoutMode } from '../types';

interface ControlsProps {
  currentLayout: LayoutMode;
  onLayoutChange: (mode: LayoutMode) => void;
}

interface ButtonProps {
  label: string;
  isActive: boolean;
  onClick: () => void;
  title?: string;
}

const ControlButton: React.FC<ButtonProps> = ({ label, isActive, onClick, title }) => {
  return (
    <button
      title={title || label}
      onClick={onClick}
      className={`px-4 py-2 text-sm font-medium rounded-full transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-indigo-400
                  ${isActive 
                    ? 'bg-indigo-500 text-white shadow-md' 
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600 hover:text-white'
                  }`}
      aria-pressed={isActive}
    >
      {label}
    </button>
  );
};

const Controls: React.FC<ControlsProps> = ({ currentLayout, onLayoutChange }) => {
  return (
    <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 mb-4 p-2 bg-gray-800 bg-opacity-80 backdrop-blur-sm rounded-full shadow-2xl flex space-x-2 items-center z-10">
      <ControlButton
        label="Grid"
        isActive={currentLayout === LayoutMode.GRID}
        onClick={() => onLayoutChange(LayoutMode.GRID)}
        title="Display videos in a grid layout"
      />
      <ControlButton
        label="Sphere"
        isActive={currentLayout === LayoutMode.SPHERE}
        onClick={() => onLayoutChange(LayoutMode.SPHERE)}
        title="Display videos in an interactive sphere"
      />
    </div>
  );
};

export default Controls;
