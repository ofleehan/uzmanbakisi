
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { VideoItem } from '../types';
import VideoCard from './VideoCard';
import { SPHERE_RADIUS, CARD_WIDTH, CARD_HEIGHT } from '../config'; // Updated import

interface SphereLayoutProps {
  videos: VideoItem[];
}

const SphereLayout: React.FC<SphereLayoutProps> = ({ videos }) => {
  const [rotation, setRotation] = useState({ x: 20, y: 0 }); // Initial rotation
  const [isDragging, setIsDragging] = useState(false);
  const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });
  const sphereRef = useRef<HTMLDivElement>(null);
  const autoRotateTimeoutRef = useRef<number | null>(null);

  const handleMouseDown = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (autoRotateTimeoutRef.current) clearTimeout(autoRotateTimeoutRef.current);
    setIsDragging(true);
    setLastMousePos({ x: e.clientX, y: e.clientY });
    if (sphereRef.current) {
      sphereRef.current.style.cursor = 'grabbing';
    }
  }, []);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const deltaX = e.clientX - lastMousePos.x;
    const deltaY = e.clientY - lastMousePos.y;
    setRotation(prev => ({
      x: prev.x - deltaY * 0.25, 
      y: prev.y + deltaX * 0.25,
    }));
    setLastMousePos({ x: e.clientX, y: e.clientY });
  }, [isDragging, lastMousePos]);

  const startAutoRotation = useCallback(() => {
    if (autoRotateTimeoutRef.current) clearTimeout(autoRotateTimeoutRef.current);
    autoRotateTimeoutRef.current = window.setTimeout(() => {
      if (isDragging) return;
      const intervalId = setInterval(() => {
        if (isDragging) { // Check again in case dragging started during interval
          clearInterval(intervalId);
          return;
        }
        setRotation(prev => ({
          x: prev.x, 
          y: prev.y + 0.05, // Slower auto-rotation
        }));
      }, 50);
      // Store intervalId to clear it if dragging starts or component unmounts
      if (sphereRef.current) {
        // A bit hacky, but attach it to the ref to clear later
         (sphereRef.current as any).autoRotateIntervalId = intervalId;
      }
    }, 2000); // Start auto-rotation after 2 seconds of inactivity
  }, [isDragging]);


  const handleMouseUpOrLeave = useCallback(() => {
    if (isDragging) {
      setIsDragging(false);
      if (sphereRef.current) {
        sphereRef.current.style.cursor = 'grab';
      }
      startAutoRotation();
    }
  }, [isDragging, startAutoRotation]);
  
  useEffect(() => {
    startAutoRotation(); // Initial auto-rotation start

    return () => {
      if (autoRotateTimeoutRef.current) clearTimeout(autoRotateTimeoutRef.current);
      if (sphereRef.current && (sphereRef.current as any).autoRotateIntervalId) {
        clearInterval((sphereRef.current as any).autoRotateIntervalId);
      }
    };
  }, [startAutoRotation]);


  const PHI = Math.PI * (3 - Math.sqrt(5)); 

  const videoElements = videos.map((video, i) => {
    const N = videos.length;
    const y_k = 1 - (2 * (i + 0.5)) / N; 
    const radius_k = Math.sqrt(1 - y_k * y_k);
    const theta_k = PHI * i;

    const xPos = Math.cos(theta_k) * radius_k;
    const zPos = Math.sin(theta_k) * radius_k;
    const yPos = y_k;

    const itemRotationY = Math.atan2(xPos, zPos) * (180 / Math.PI);
    const itemRotationX = Math.asin(-yPos) * (180 / Math.PI); 
    
    const transformStyle = `rotateY(${itemRotationY}deg) rotateX(${itemRotationX}deg) translateZ(${SPHERE_RADIUS}px)`;
    
    return (
      <VideoCard
        key={video.id}
        video={video}
        style={{ transform: transformStyle }}
        isSphereItem={true}
      />
    );
  });

  return (
    <div
      ref={sphereRef}
      className="w-full h-full flex items-center justify-center cursor-grab"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUpOrLeave}
      onMouseLeave={handleMouseUpOrLeave}
      style={{ touchAction: 'none' }} 
    >
      <div
        className="sphere-container relative"
        style={{
          width: `${CARD_WIDTH}px`, 
          height: `${CARD_HEIGHT}px`,
          transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)`,
        }}
      >
        {videoElements}
      </div>
    </div>
  );
};

export default SphereLayout;
