
import React from 'react';
import { LayoutMode } from '../types'; // Import LayoutMode

const EGOPROMEDIA_LOGO_URL = "https://i.imgur.com/Vd2ETAj.png";
const EGOPROMEDIA_LINK = "https://egopro.com.tr/";

interface EgopromediaLogosProps {
  layoutMode: LayoutMode;
}

const EgopromediaLogos: React.FC<EgopromediaLogosProps> = ({ layoutMode }) => {
  const logoBaseClasses = "fixed top-1/2 -translate-y-1/2 z-20 transition-transform duration-300 ease-in-out hover:scale-110 animate-phoenix-rise";
  const logoSizeClasses = "w-24 h-auto md:w-32 lg:w-40"; // Responsive sizing

  if (layoutMode === LayoutMode.GRID) {
    return null; // Hide logos in Grid mode
  }

  return (
    <>
      {/* Left Logo */}
      <a
        href={EGOPROMEDIA_LINK}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Visit Egopromedia (Left Logo)"
        title="Visit Egopromedia"
        className={`${logoBaseClasses} left-2 sm:left-4 md:left-6`}
      >
        <img 
          src={EGOPROMEDIA_LOGO_URL} 
          alt="Egopromedia Logo" 
          className={logoSizeClasses}
        />
      </a>

      {/* Right Logo */}
      <a
        href={EGOPROMEDIA_LINK}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Visit Egopromedia (Right Logo)"
        title="Visit Egopromedia"
        className={`${logoBaseClasses} right-2 sm:right-4 md:right-6`}
        // style={{ animationDelay: '0.7s' }} // Optional different delay
      >
        <img 
          src={EGOPROMEDIA_LOGO_URL} 
          alt="Egopromedia Logo" 
          className={logoSizeClasses}
        />
      </a>
    </>
  );
};

export default EgopromediaLogos;