import React from 'react';
import { CHANNELS } from '../constants';

const ChannelLogos: React.FC = () => {
  return (
    <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2 mb-1 p-2 bg-gray-800 bg-opacity-70 backdrop-blur-sm rounded-lg shadow-xl flex space-x-4 items-center z-10">
      {Object.values(CHANNELS).map(channel => {
        const isNtv = channel.name === 'NTV - Uzman Bakışı';
        const isTv100 = channel.name === 'TV100 - Doğrusu Nedir?';
        const isTlc = channel.name === 'TLC - Soru Cevap';

        let logoHeightClass = 'h-12'; // Default for CNN
        let logoStyleHeight = '3rem'; // Default for CNN

        if (isNtv || isTv100) {
          logoHeightClass = 'h-10';
          logoStyleHeight = '2.5rem';
        } else if (isTlc) {
          logoHeightClass = 'h-14'; // Larger for TLC
          logoStyleHeight = '3.5rem';
        }

        return (
          <a
            key={channel.name}
            href={channel.yt}
            target="_blank"
            rel="noopener noreferrer"
            title={`Visit ${channel.name} on YouTube`}
            className="transition-transform duration-200 ease-in-out hover:scale-110 focus:outline-none focus:ring-2 focus:ring-indigo-400 rounded flex items-center justify-center"
            aria-label={`Visit ${channel.name} on YouTube`}
            style={{ height: logoStyleHeight }} 
          >
            <img
              src={channel.logoUrl}
              alt={`${channel.name} Logo`}
              className={`${logoHeightClass} w-auto max-w-[120px] object-contain rounded`}
              onError={(e) => {
                const img = e.target as HTMLImageElement;
                console.error(`Failed to load logo for ${channel.name}: ${img.src}`);
                // Visual indication of error without breaking layout significantly
                img.style.outline = '2px dashed red';
                img.style.backgroundColor = 'rgba(255,0,0,0.1)';
              }}
            />
          </a>
        );
      })}
    </div>
  );
};

export default ChannelLogos;