
import React from 'react';
import { VideoItem } from '../types';
import VideoCard from './VideoCard';
import { CARD_WIDTH } from '../config'; // Updated import

interface GridLayoutProps {
  videos: VideoItem[];
}

const GridLayout: React.FC<GridLayoutProps> = ({ videos }) => {
  return (
    <div className="w-full h-full p-6 md:p-8 lg:p-12 overflow-y-auto">
      <div 
        className="grid gap-4 md:gap-6"
        style={{
            gridTemplateColumns: `repeat(auto-fill, minmax(${CARD_WIDTH + 10}px, 1fr))`
        }}
      >
        {videos.map(video => (
          <VideoCard key={video.id} video={video} />
        ))}
      </div>
    </div>
  );
};

export default GridLayout;
